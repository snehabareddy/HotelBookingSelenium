package hotelbooking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private WebElement element;
	
	@Before
	public void setup() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\data\\chromedriver.exe");
		webdriver=new ChromeDriver();
		webdriver.get("file:///C:/myworkspace/HotelBookingApplication/src/main/webapp/pages/hotelbooking.html");
		String title=webdriver.getTitle();
		assertEquals("Hotel Booking", title);
	}
	
	
	@Given("^Valid User Details$")
	public void valid_User_Details() throws Throwable {
		webdriver.findElement(By.id("txtFirstName")).sendKeys("Tom");
		webdriver.findElement(By.id("txtLastName")).sendKeys("Jerry");
		webdriver.findElement(By.id("txtEmail")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.id("txtPhone")).sendKeys("8919659107");
		webdriver.findElement(By.tagName("textarea")).sendKeys("Chennai");
		Select city=new Select(webdriver.findElement(By.name("city")));
		city.selectByVisibleText("Hyderabad");
		Select state=new Select(webdriver.findElement(By.name("state")));
		state.selectByVisibleText("Telangana");
		Select persons=new Select(webdriver.findElement(By.name("persons")));
		persons.selectByVisibleText("1");
		webdriver.findElement(By.id("txtCardholderName")).sendKeys("Tom");
		webdriver.findElement(By.id("txtDebit")).sendKeys("456789123");
		webdriver.findElement(By.name("cvv")).sendKeys("782");
		webdriver.findElement(By.id("txtMonth")).sendKeys("November");
		webdriver.findElement(By.id("txtYear")).sendKeys("2018");
		Thread.sleep(2000);
	}

	@When("^On Submit$")
	public void on_Submit() throws Throwable {
		element = webdriver.findElement(By.id("btnPayment"));
		element.click();
		Thread.sleep(2000);

	}

	@Then("^Navigate to Success page$")
	public void navigate_to_Success_page() throws Throwable {
		Thread.sleep(2000);

	}

	@Given("^Invalid User Details$")
	public void invalid_User_Details() throws Throwable {
		webdriver.findElement(By.id("txtFirstName")).sendKeys("Tom");
		webdriver.findElement(By.id("txtLastName")).sendKeys("Jerry");
		webdriver.findElement(By.id("txtEmail")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.id("txtPhone")).sendKeys("");
		webdriver.findElement(By.tagName("textarea")).sendKeys("Chennai");
		Select city=new Select(webdriver.findElement(By.name("city")));
		city.selectByVisibleText("Hyderabad");
		Select state=new Select(webdriver.findElement(By.name("state")));
		state.selectByVisibleText("Telangana");
		Select persons=new Select(webdriver.findElement(By.name("persons")));
		persons.selectByVisibleText("1");
		webdriver.findElement(By.id("txtCardholderName")).sendKeys("Tom");
		webdriver.findElement(By.id("txtDebit")).sendKeys("456789123");
		webdriver.findElement(By.name("cvv")).sendKeys("782");
		webdriver.findElement(By.id("txtMonth")).sendKeys("November");
		webdriver.findElement(By.id("txtYear")).sendKeys("2018");
		Thread.sleep(2000);

	}

	@Then("^Display the error message$")
	public void display_the_error_message() throws Throwable {
		/*webdriver.switchTo().alert().accept();
		webdriver.findElement(By.id("txtPhone")).sendKeys("7098765678");
		element = webdriver.findElement(By.id("btnPayment"));
		element.click();*/
		Thread.sleep(2000);

	}
	
	@After
	public void teardown() {
		//webdriver.quit();
	}



}
